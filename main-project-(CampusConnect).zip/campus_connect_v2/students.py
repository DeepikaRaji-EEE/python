"""
students.py
------------
Core student-record operations for Campus Connect:
add, search, update, delete, grade calculation, and
class average — the "inventory" of student data.
"""

import data_manager as dm


# ---------------------------------------------------------
# FUNCTION: calculate_grade
# Converts numeric marks into a letter grade.
# ---------------------------------------------------------
def calculate_grade(marks):
    if marks >= 90:
        return "A+"
    elif marks >= 75:
        return "A"
    elif marks >= 60:
        return "B"
    elif marks >= 40:
        return "C"
    else:
        return "Fail"


# ---------------------------------------------------------
# FUNCTION: add_student
# Adds a new student record and logs the action.
# ---------------------------------------------------------
def add_student(students, roll_no, name, marks):
    students[roll_no] = {
        "name": name,
        "marks": marks,
        "grade": calculate_grade(marks)
    }
    dm.save_students(students)
    dm.add_log_entry("ADD", roll_no, f"{name} - {marks} marks")


# ---------------------------------------------------------
# FUNCTION: search_student
# Returns the student's record dict, or None if not found.
# ---------------------------------------------------------
def search_student(students, roll_no):
    return students.get(roll_no)


# ---------------------------------------------------------
# FUNCTION: update_marks
# Updates an existing student's marks and recalculates grade.
# ---------------------------------------------------------
def update_marks(students, roll_no, new_marks):
    if roll_no not in students:
        return False

    students[roll_no]["marks"] = new_marks
    students[roll_no]["grade"] = calculate_grade(new_marks)
    dm.save_students(students)
    dm.add_log_entry("UPDATE", roll_no, f"Marks changed to {new_marks}")
    return True


# ---------------------------------------------------------
# FUNCTION: delete_student
# Removes a student record.
# ---------------------------------------------------------
def delete_student(students, roll_no):
    if roll_no not in students:
        return False

    removed = students.pop(roll_no)
    dm.save_students(students)
    dm.add_log_entry("DELETE", roll_no, f"{removed['name']} removed")
    return True


# ---------------------------------------------------------
# FUNCTION: class_average
# Calculates the average marks across all students.
# ---------------------------------------------------------
def class_average(students):
    if not students:
        return 0

    total = 0
    for info in students.values():     # loop through all records
        total += info["marks"]

    return total / len(students)


# ---------------------------------------------------------
# FUNCTION: topper
# Finds the student with the highest marks.
# ---------------------------------------------------------
def topper(students):
    if not students:
        return None

    best_roll = None
    best_marks = -1
    for roll_no, info in students.items():
        if info["marks"] > best_marks:
            best_marks = info["marks"]
            best_roll = roll_no

    return best_roll, students[best_roll]
