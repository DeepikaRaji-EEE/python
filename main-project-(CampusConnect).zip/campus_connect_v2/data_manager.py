"""
data_manager.py
----------------
Handles all data persistence for Campus Connect.
Responsible for reading/writing the student records file
and maintaining a simple activity log (who did what, when).
"""

import json
import os
from datetime import datetime

STUDENTS_FILE = "students.json"
LOG_FILE = "activity_log.json"


# ---------------------------------------------------------
# STUDENT RECORDS
# ---------------------------------------------------------
def load_students():
    """Load all student records from the JSON file into a dict."""
    if os.path.exists(STUDENTS_FILE):
        with open(STUDENTS_FILE, "r") as file:
            return json.load(file)
    return {}


def save_students(students):
    """Save the given student dictionary back to the JSON file."""
    with open(STUDENTS_FILE, "w") as file:
        json.dump(students, file, indent=4)


# ---------------------------------------------------------
# ACTIVITY LOG
# ---------------------------------------------------------
def load_log():
    """Load the activity log (list of past actions) from file."""
    if os.path.exists(LOG_FILE):
        with open(LOG_FILE, "r") as file:
            return json.load(file)
    return []


def add_log_entry(action, roll_no, details=""):
    """
    Append a new entry to the activity log and save it.
    Example: add_log_entry("ADD", "101", "Arun - 85 marks")
    """
    log = load_log()
    entry = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "action": action,
        "roll_no": roll_no,
        "details": details
    }
    log.append(entry)

    with open(LOG_FILE, "w") as file:
        json.dump(log, file, indent=4)
