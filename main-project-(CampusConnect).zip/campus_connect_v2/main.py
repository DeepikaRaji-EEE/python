"""
main.py
-------
Campus Connect: A Python Tkinter Student Management Application
------------------------------------------------------------------
GUI entry point. Wires together:
    data_manager.py  -> file storage + activity log
    students.py      -> student record operations (CRUD)
    reports.py       -> report card / class summary generation

Run this file to start the application:
    python main.py
"""

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import os

import data_manager as dm
import students as st
import reports as rp


class CampusConnectApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Campus Connect - Student Management System")
        self.root.geometry("800x560")
        self.root.resizable(False, False)

        # Load existing data on startup
        self.students = dm.load_students()

        self.build_header()
        self.build_form()
        self.build_buttons()
        self.build_table()

        self.refresh_table()

    # -------------------------------------------------
    # HEADER (logo + titles)
    # -------------------------------------------------
    def build_header(self):
        header = tk.Frame(self.root)
        header.pack(pady=(12, 0), fill="x")

        logo_path = os.path.join(os.path.dirname(__file__), "logo.png")
        if os.path.exists(logo_path):
            self.logo_img = tk.PhotoImage(file=logo_path).subsample(6, 6)
            tk.Label(header, image=self.logo_img).pack(side="left", padx=(20, 10))

        text_frame = tk.Frame(header)
        text_frame.pack(side="left")

        tk.Label(
            text_frame, text="Campus Connect",
            font=("Segoe UI", 20, "bold"), fg="#2c3e50"
        ).pack(anchor="w")
        tk.Label(
            text_frame, text="Student Management Application",
            font=("Segoe UI", 11), fg="#7f8c8d"
        ).pack(anchor="w")

    # -------------------------------------------------
    # INPUT FORM
    # -------------------------------------------------
    def build_form(self):
        form_frame = tk.Frame(self.root)
        form_frame.pack(pady=12)

        labels = ["Roll No", "Name", "Marks"]
        self.entries = {}

        for i, label_text in enumerate(labels):
            tk.Label(form_frame, text=label_text, font=("Segoe UI", 10)).grid(
                row=0, column=i * 2, padx=5, pady=5
            )
            entry = tk.Entry(form_frame, width=15)
            entry.grid(row=0, column=i * 2 + 1, padx=5, pady=5)
            self.entries[label_text] = entry

    # -------------------------------------------------
    # ACTION BUTTONS
    # -------------------------------------------------
    def build_buttons(self):
        btn_frame = tk.Frame(self.root)
        btn_frame.pack(pady=6)

        buttons = [
            ("Add", self.add_student, "#27ae60"),
            ("Update", self.update_student, "#2980b9"),
            ("Delete", self.delete_student, "#c0392b"),
            ("Search", self.search_student, "#8e44ad"),
            ("Clear", self.clear_form, "#7f8c8d"),
            ("Report Card", self.show_report_card, "#d35400"),
            ("Class Summary", self.show_class_summary, "#16a085"),
        ]

        for text, command, color in buttons:
            tk.Button(
                btn_frame, text=text, command=command,
                bg=color, fg="white", font=("Segoe UI", 9, "bold"),
                width=13, relief="flat", cursor="hand2"
            ).pack(side="left", padx=3)

    # -------------------------------------------------
    # TABLE (Treeview) TO DISPLAY RECORDS
    # -------------------------------------------------
    def build_table(self):
        columns = ("roll_no", "name", "marks", "grade")
        self.tree = ttk.Treeview(self.root, columns=columns, show="headings", height=13)

        headings = {
            "roll_no": "Roll No", "name": "Name",
            "marks": "Marks", "grade": "Grade"
        }
        for col in columns:
            self.tree.heading(col, text=headings[col])
            self.tree.column(col, anchor="center", width=160)

        self.tree.pack(pady=10, padx=15, fill="x")
        self.tree.bind("<<TreeviewSelect>>", self.on_row_select)

    # -------------------------------------------------
    # REFRESH TABLE FROM self.students DICTIONARY
    # -------------------------------------------------
    def refresh_table(self):
        for row in self.tree.get_children():
            self.tree.delete(row)

        for roll_no, info in self.students.items():
            self.tree.insert(
                "", "end",
                values=(roll_no, info["name"], info["marks"], info["grade"])
            )

    # -------------------------------------------------
    # FUNCTION: get_form_values
    # -------------------------------------------------
    def get_form_values(self):
        roll_no = self.entries["Roll No"].get().strip()
        name = self.entries["Name"].get().strip()
        marks_text = self.entries["Marks"].get().strip()
        return roll_no, name, marks_text

    # -------------------------------------------------
    # FUNCTION: add_student
    # -------------------------------------------------
    def add_student(self):
        roll_no, name, marks_text = self.get_form_values()

        if not roll_no or not name or not marks_text:
            messagebox.showwarning("Missing Info", "Please fill all fields.")
            return

        try:
            marks = float(marks_text)
        except ValueError:
            messagebox.showerror("Invalid Marks", "Marks must be a number.")
            return

        if roll_no in self.students:
            messagebox.showerror("Duplicate Roll No", "This Roll No already exists.")
            return

        st.add_student(self.students, roll_no, name, marks)
        self.refresh_table()
        self.clear_form()
        messagebox.showinfo("Success", f"Student '{name}' added successfully.")

    # -------------------------------------------------
    # FUNCTION: update_student
    # -------------------------------------------------
    def update_student(self):
        roll_no, name, marks_text = self.get_form_values()

        if not roll_no or not marks_text:
            messagebox.showwarning("Missing Info", "Enter Roll No and Marks to update.")
            return

        try:
            marks = float(marks_text)
        except ValueError:
            messagebox.showerror("Invalid Marks", "Marks must be a number.")
            return

        success = st.update_marks(self.students, roll_no, marks)
        if success:
            self.refresh_table()
            self.clear_form()
            messagebox.showinfo("Updated", f"Marks updated for Roll No {roll_no}.")
        else:
            messagebox.showerror("Not Found", f"No student found with Roll No {roll_no}.")

    # -------------------------------------------------
    # FUNCTION: delete_student
    # -------------------------------------------------
    def delete_student(self):
        roll_no, _, _ = self.get_form_values()

        if not roll_no:
            messagebox.showwarning("Missing Info", "Enter Roll No to delete.")
            return

        success = st.delete_student(self.students, roll_no)
        if success:
            self.refresh_table()
            self.clear_form()
            messagebox.showinfo("Deleted", f"Student with Roll No {roll_no} removed.")
        else:
            messagebox.showerror("Not Found", f"No student found with Roll No {roll_no}.")

    # -------------------------------------------------
    # FUNCTION: search_student
    # -------------------------------------------------
    def search_student(self):
        roll_no, _, _ = self.get_form_values()

        if not roll_no:
            messagebox.showwarning("Missing Info", "Enter Roll No to search.")
            return

        info = st.search_student(self.students, roll_no)
        if info:
            self.entries["Name"].delete(0, tk.END)
            self.entries["Name"].insert(0, info["name"])
            self.entries["Marks"].delete(0, tk.END)
            self.entries["Marks"].insert(0, info["marks"])
            messagebox.showinfo(
                "Found",
                f"Roll No: {roll_no}\nName: {info['name']}\n"
                f"Marks: {info['marks']}\nGrade: {info['grade']}"
            )
        else:
            messagebox.showerror("Not Found", f"No student found with Roll No {roll_no}.")

    # -------------------------------------------------
    # FUNCTION: show_report_card
    # Uses reports.py to build and display a report card
    # -------------------------------------------------
    def show_report_card(self):
        roll_no, _, _ = self.get_form_values()

        if not roll_no:
            messagebox.showwarning("Missing Info", "Enter Roll No to generate report.")
            return

        info = st.search_student(self.students, roll_no)
        if not info:
            messagebox.showerror("Not Found", f"No student found with Roll No {roll_no}.")
            return

        report_text = rp.generate_report_card(roll_no, info)
        self.show_text_window("Report Card", report_text)

    # -------------------------------------------------
    # FUNCTION: show_class_summary
    # Uses reports.py to build and display a class summary
    # -------------------------------------------------
    def show_class_summary(self):
        summary_text = rp.generate_class_summary(self.students)
        self.show_text_window("Class Summary", summary_text)

    # -------------------------------------------------
    # FUNCTION: show_text_window
    # Small popup window to display a formatted report
    # -------------------------------------------------
    def show_text_window(self, title, text):
        win = tk.Toplevel(self.root)
        win.title(title)
        win.geometry("420x320")
        win.resizable(False, False)

        box = scrolledtext.ScrolledText(win, font=("Courier New", 10), wrap="word")
        box.pack(fill="both", expand=True, padx=10, pady=10)
        box.insert("1.0", text)
        box.configure(state="disabled")

    # -------------------------------------------------
    # FUNCTION: on_row_select
    # -------------------------------------------------
    def on_row_select(self, event):
        selected = self.tree.focus()
        if not selected:
            return
        values = self.tree.item(selected, "values")
        self.clear_form()
        self.entries["Roll No"].insert(0, values[0])
        self.entries["Name"].insert(0, values[1])
        self.entries["Marks"].insert(0, values[2])

    # -------------------------------------------------
    # FUNCTION: clear_form
    # -------------------------------------------------
    def clear_form(self):
        for entry in self.entries.values():
            entry.delete(0, tk.END)


# ---------------------------------------------------------
# Program entry point
# ---------------------------------------------------------
if __name__ == "__main__":
    root = tk.Tk()
    app = CampusConnectApp(root)
    root.mainloop()
