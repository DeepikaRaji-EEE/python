"""
reports.py
----------
Generates printable text reports for Campus Connect:
individual student report cards and whole-class summaries.
(This module plays the same role "billing.py" plays in a
 shop app — turning stored data into a formatted document.)
"""

import students as st
from datetime import datetime


# ---------------------------------------------------------
# FUNCTION: generate_report_card
# Builds a formatted report card for a single student.
# ---------------------------------------------------------
def generate_report_card(roll_no, info):
    lines = [
        "=" * 40,
        "        CAMPUS CONNECT - REPORT CARD",
        "=" * 40,
        f"Roll No : {roll_no}",
        f"Name    : {info['name']}",
        f"Marks   : {info['marks']}",
        f"Grade   : {info['grade']}",
        "-" * 40,
        f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "=" * 40,
    ]
    return "\n".join(lines)


# ---------------------------------------------------------
# FUNCTION: generate_class_summary
# Builds a summary report for the whole class.
# ---------------------------------------------------------
def generate_class_summary(students):
    if not students:
        return "No student records available."

    avg = st.class_average(students)
    top_roll, top_info = st.topper(students)

    lines = [
        "=" * 40,
        "        CAMPUS CONNECT - CLASS SUMMARY",
        "=" * 40,
        f"Total Students   : {len(students)}",
        f"Class Average    : {avg:.2f}",
        f"Topper           : {top_info['name']} (Roll No {top_roll}, {top_info['marks']} marks)",
        "-" * 40,
        f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "=" * 40,
    ]
    return "\n".join(lines)
