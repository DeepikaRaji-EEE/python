"""
student_utils.py
-----------------
Backend module for Campus Connect.
Handles all data operations: add, view, search, update, delete,
grade calculation, and saving/loading data to a JSON file.
"""

import json
import os

DATA_FILE = "students.json"


# ---------------------------------------------------------
# Load student data from JSON file into a dictionary
# ---------------------------------------------------------
def load_data():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r") as file:
            return json.load(file)
    return {}


# ---------------------------------------------------------
# Save student dictionary back into the JSON file
# ---------------------------------------------------------
def save_data(students):
    with open(DATA_FILE, "w") as file:
        json.dump(students, file, indent=4)


# ---------------------------------------------------------
# Calculate grade based on marks
# ---------------------------------------------------------
def calculate_grade(marks):
    if marks >= 90:
        return "A+"
    elif marks >= 75:
        return "A"
    elif marks >= 60:
        return "B"
    elif marks >= 40:
        return "C"
    else:
        return "Fail"


# ---------------------------------------------------------
# Add a new student record
# ---------------------------------------------------------
def add_student(students, roll_no, name, marks):
    students[roll_no] = {
        "name": name,
        "marks": marks,
        "grade": calculate_grade(marks)
    }
    save_data(students)


# ---------------------------------------------------------
# Update an existing student's marks
# ---------------------------------------------------------
def update_marks(students, roll_no, new_marks):
    if roll_no in students:
        students[roll_no]["marks"] = new_marks
        students[roll_no]["grade"] = calculate_grade(new_marks)
        save_data(students)
        return True
    return False


# ---------------------------------------------------------
# Delete a student record
# ---------------------------------------------------------
def delete_student(students, roll_no):
    if roll_no in students:
        students.pop(roll_no)
        save_data(students)
        return True
    return False


# ---------------------------------------------------------
# Calculate class average marks
# ---------------------------------------------------------
def class_average(students):
    if not students:
        return 0
    total = sum(info["marks"] for info in students.values())
    return total / len(students)
